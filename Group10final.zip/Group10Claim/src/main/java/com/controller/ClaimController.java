package com.controller;
import com.dao.Claimdao;
import com.dao.ClaimdaoImpl;
import com.model.Ticket;
import com.model.Users;
import com.model.Policy;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ClaimController{
	 @Autowired  
	   ClaimdaoImpl dao;
	 int uid;
	@RequestMapping("/id")
	public ModelAndView Show(HttpServletRequest request,HttpServletResponse response){
		 uid=Integer.parseInt(request.getParameter("uid"));
		String s=dao.check(uid);
		ModelAndView mv=new ModelAndView("Success");
		mv.addObject("msg", s);
		 List<Policy>str=dao.show(uid);
		 mv.addObject("list", str);
		return mv;
	}
	@RequestMapping("/claim")
	public ModelAndView ticket() {
		Random rnd = new Random();
		long n = 100000 + rnd.nextInt(900000);
Ticket t=new Ticket();
		t.setTicket_no(n);
		long i=dao.saveTicket(t, uid);
		ModelAndView mv=new ModelAndView("Token");
		mv.addObject("ticket", n);
		return mv;
	}
}