package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.dao.Claimdao;
import com.model.Policy;
import com.model.Ticket;
public class ClaimServiceImpl implements ClaimService{
	@Autowired
	Claimdao claimDao;
	public List<Policy> show(int uid) {
		return claimDao.show(uid);
	}
	public int saveTicket(Ticket r, int uid) {
		return claimDao.saveTicket(r, uid);
	}
	public String check(int uid) {
		return claimDao.check(uid);
	}
}
