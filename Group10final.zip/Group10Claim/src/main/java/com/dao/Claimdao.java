package com.dao;

import java.util.List;

import com.model.Policy;
import com.model.Ticket;

public interface Claimdao {
	List<Policy> show(int uid);
	int saveTicket(Ticket r,int uid);
	String check(int uid);
}
