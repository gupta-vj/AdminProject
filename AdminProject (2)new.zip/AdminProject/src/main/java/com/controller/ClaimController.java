package com.controller;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.dao.AdminDaoImpl;
@Controller
public class ClaimController {
	@Autowired
	AdminDaoImpl adao;
	 @RequestMapping(value = "/deduct")
	 public ModelAndView Claim(HttpServletRequest request) {
		 ModelAndView mv= new ModelAndView();
		 HttpSession session=request.getSession(false);
		 int amt = (Integer) session.getAttribute("amount");
		 int id = (Integer) session.getAttribute("id");
		 int amount=Integer.parseInt(request.getParameter("claimamount"));
		 if(amount>amt) {
			 mv.addObject("previous", amt);
			 mv.addObject("original", amount);
			 mv.setViewName("Invalid");
		 }
		 else {
			 adao.getclaim(amt, amount,id);
			 mv.setViewName("valid");
		 }
		
		return mv;
	 }
}
