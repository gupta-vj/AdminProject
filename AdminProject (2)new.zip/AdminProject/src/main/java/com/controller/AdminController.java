package com.controller;
import java.io.IOException;
import java.rmi.ServerException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dao.AdminDaoImpl;
import com.model.Admin;
import com.model.Policy;
import com.model.Ticket;
import com.model.Users;
@Controller
public class AdminController {
	@Autowired
	AdminDaoImpl adao;
	private long value;
	@RequestMapping(value="/adminloginProcess")
	  public ModelAndView adminloginProcess(HttpServletRequest request) throws ServerException,IOException, ServletException {
		  ModelAndView mv = null;
		  String user=request.getParameter("username");
		  String pass=request.getParameter("password");
		  Admin a=new Admin();
		  a.setUsername(user);
		  a.setPassword(pass);
		  if(a.getUsername().equals("vijay") && a.getPassword().equals("123456")) {
			  List<Users> lst = new ArrayList<Users>();
			  List<Policy> l = new ArrayList<Policy>();
			  List<Ticket> t = new ArrayList<Ticket>();
				lst = adao.getAllUsers();
				request.setAttribute("usrList",lst);
				t = adao.getAllTicket();
				request.setAttribute("tickets",t);
				l = adao.getAllPolicy();
				request.setAttribute("PolicyList",l);
			  mv = new ModelAndView("userinfo");
		  }else {
			  mv = new ModelAndView("nosuch");
			  mv.addObject("message", "Username or Password is wrong!!");
		  }
		  return mv;
	  }
	 @RequestMapping(value="/deleteusr/{id}")  
	    public ModelAndView deleteUser(@PathVariable int id){  
	        adao.deleteUser(id);  
	        return new ModelAndView("deleted");  
	    }
	 @RequestMapping(value="/deletepolicy/{policy_id}")  
	    public ModelAndView deletePolicy(@PathVariable int policy_id){  
	        adao.deletePolicy(policy_id);  
	        return new ModelAndView("deleted");  
	    }  
	 @RequestMapping(value="/deletetickets/{ticket_no}")  
	    public ModelAndView deleteTicket(@PathVariable long ticket_no){  
	        adao.deletetickets(ticket_no); 
	        return new ModelAndView("deleted");  
	    }  
	 @RequestMapping(value="approvetickets/{ticket_no}")
	 public ModelAndView approveTicket(@PathVariable long ticket_no) {
		 Ticket p = new Ticket();
		 p.setTicket_no(ticket_no);
		 value=p.getTicket_no();	 
		List<Ticket> lst= adao.getTicketByNo(ticket_no);
		int status = lst.get(0).getStatus();
		adao.approveTicket(status,value);
		 return new ModelAndView("Approved");
	 }
	 @RequestMapping(value="/claim_amount/{claim_amount},{policy_id}")
	 public ModelAndView Claim(@PathVariable int claim_amount,HttpServletRequest request,@PathVariable int policy_id) {
		 HttpSession session = request.getSession();
		 session.setAttribute("amount", claim_amount);
		 session.setAttribute("id", policy_id);
		 return new ModelAndView("CLAIM");
	 }
}


	 
	
