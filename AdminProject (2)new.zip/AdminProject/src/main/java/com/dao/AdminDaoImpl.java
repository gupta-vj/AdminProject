package com.dao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import com.model.Policy;
import com.model.Ticket;
import com.model.Users;
public class AdminDaoImpl implements AdminDao{  
JdbcTemplate template;
public int status;  
public void setTemplate(JdbcTemplate template) {  
    this.template = template;  
}  
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.template = jdbcTemplate;
	}
	public List<Users> getAllUsers(){  
		 return template.query("select * from Users",new ResultSetExtractor<List<Users>>(){  
		    public List<Users> extractData(ResultSet rs) throws SQLException, DataAccessException {    
		        List<Users> list=new ArrayList<Users>();  
		        while(rs.next()){  
		        Users user=new Users();  
		        user.setId(rs.getInt("id"));
			    user.setAge(rs.getInt("age"));
			    user.setName(rs.getString("name"));
			    user.setContact(rs.getLong("contact"));
			    user.setEmail(rs.getString("email"));
			    user.setPassword(rs.getString("password"));
		        list.add(user);  
		        }  
		        return list;  
		        }  
		 });  
	}
	public List<Policy> getAllPolicy(){  
		 return template.query("select * from gr10_policies",new ResultSetExtractor<List<Policy>>(){  
		    public List<Policy> extractData(ResultSet rs) throws SQLException, DataAccessException {    
		        List<Policy> list=new ArrayList<Policy>();  
		        while(rs.next()){  
		        Policy user=new Policy();  
		        user.setPolicy_id(rs.getInt("policy_id"));
		        user.setUser_id(rs.getInt("User_id"));
		        user.setRegistration_no(rs.getInt("registration_no"));
		        user.setPolicy_status(rs.getInt("policy_status"));
		        user.setClaim_amount(rs.getInt("Claim_amount"));
		        list.add(user);  
		        }  
		        return list;  
		        }  
		 });  
	}
	public List<Ticket> getAllTicket(){  
		 return template.query("select * from gr10_ticket",new ResultSetExtractor<List<Ticket>>(){  
		    public List<Ticket> extractData(ResultSet rs) throws SQLException, DataAccessException {    
		        List<Ticket> list=new ArrayList<Ticket>();  
		        while(rs.next()){  
		        Ticket t=new Ticket();  
		        t.setTicket_no(rs.getLong("Ticket_no"));
		        t.setPolicy_no(rs.getInt("policy_id"));
		        t.setStatus(rs.getInt("status"));
		        list.add(t);  
		        }  
		        return list;  
		        }  
		 });  
	}
		 public List<Ticket> getTicketByNo(long ticket_no){
				String s="select * from gr10_ticket where ticket_no="+ticket_no;
				return template.query(s, new ResultSetExtractor<List<Ticket>>(){  
				    public List<Ticket> extractData(ResultSet rs) throws SQLException, DataAccessException {    
				        List<Ticket> list=new ArrayList<Ticket>();  
				        while(rs.next()){    	
				        	Ticket p = new Ticket();
				        	p.setTicket_no(rs.getLong(1));
				        	p.setStatus(rs.getInt(3));
				        	p.setPolicy_no(rs.getInt(2));
				        	list.add(p);
				        }
				      return list;
				}
				});
			}
		
	 public int deleteUser(int id){  
	    String sql="delete from Users where id="+id+"";  
	    return template.update(sql);  
	}   
	public int deletePolicy(int policy_id){  
	    String sql="delete from gr10_policies where policy_id="+policy_id+"";  
	    return template.update(sql);  
	}  
	public int deletetickets(long ticket_no){  
	    String sql="delete from gr10_ticket where ticket_no="+ticket_no+"";  
	    return template.update(sql);  
	}  
	
	public int approveTicket(int status,long ticket_no) {
		int i=0;
		 if(status==0) {	 
				String sql="update gr10_ticket set status = '"+1+"' where ticket_no = "+ticket_no;
				 i= template.update(sql);
		}
		 return i;
	}
	public int getclaim(int amt,int amount,int id) {
		int i=0;
		String sql="update gr10_policies set claim_amount="+(amt-amount)+"where policy_id="+id;
		i=template.update(sql);
		return i;
	}
	
}
		 

