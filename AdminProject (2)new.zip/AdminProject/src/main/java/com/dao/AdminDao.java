package com.dao;

import java.util.List;

import com.model.Policy;
import com.model.Ticket;
import com.model.Users;

public interface AdminDao {
	public List<Users> getAllUsers();
	public List<Policy> getAllPolicy();
	public List<Ticket> getAllTicket();
	public List<Ticket> getTicketByNo(long ticket_no);
	 public int deleteUser(int id);
	 public int deletePolicy(int policy_id);
		public int deletetickets(long ticket_no);
		public int approveTicket(int status,long ticket_no);
		public int getclaim(int amt,int amount,int id) ;
}
