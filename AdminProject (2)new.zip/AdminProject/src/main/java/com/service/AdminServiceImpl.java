package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.dao.AdminDao;

import com.model.Policy;
import com.model.Ticket;
import com.model.Users;
public class AdminServiceImpl implements AdminService{
	@Autowired
	AdminDao claimDao;
	public List<Users> getAllUsers(){
		return claimDao.getAllUsers();
	}
	public List<Policy> getAllPolicy(){
		return claimDao.getAllPolicy();
	}
	public List<Ticket> getAllTicket(){
		return claimDao.getAllTicket();
	}
	public List<Ticket> getTicketByNo(long ticket_no){
		return claimDao.getTicketByNo(ticket_no);
	}
	 public int deleteUser(int id) {
		 return claimDao.deleteUser(id);
	 }
	 public int deletePolicy(int policy_id) {
		 return claimDao.deletePolicy(policy_id);
	 }
		public int deletetickets(long ticket_no) {
			return claimDao.deletetickets(ticket_no);
		}
		public int approveTicket(int status,long ticket_no) {
			return claimDao.approveTicket(status, ticket_no);
		}
		public int getclaim(int amt,int amount,int id) {
			return claimDao.getclaim(amt, amount, id);
		}

	}