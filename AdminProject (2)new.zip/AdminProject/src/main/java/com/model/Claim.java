package com.model;

public class Claim {
private int claim_amount;

public int getClaim_amount() {
	return claim_amount;
}

public void setClaim_amount(int claim_amount) {
	this.claim_amount = claim_amount;
}

}
